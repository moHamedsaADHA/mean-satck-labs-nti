var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//  a. Type annotations & union types
function me(name, age) {
    if (name === void 0) { name = "mohamed"; }
    if (age === void 0) { age = 20; }
    return "Name: ".concat(name, ", Age: ").concat(age);
}
console.log(me("saad", 52));
//  b. Function with typed arguments and return type
function add(a, b) {
    return a + b;
}
console.log(add(5, 10));
var user = {
    name: "mohamed",
    age: 20
};
// Class using interface
var User = /** @class */ (function () {
    function User(name, age) {
        this.name = name;
        this.age = age;
    }
    return User;
}());
// Inheritance
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee(name, age, role) {
        var _this = _super.call(this, name, age) || this;
        _this.role = role;
        return _this;
    }
    return Employee;
}(User));
var emp = new Employee("MoSHa", 20, "Developer");
console.log(emp);
//  d. Default, optional, and rest parameters
function greet(name, age) {
    if (name === void 0) { name = "Guest"; }
    var skills = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        skills[_i - 2] = arguments[_i];
    }
    console.log("Hello ".concat(name, ", Age: ").concat(age, ", Skills: ").concat(skills.join(", ")));
}
greet("mohameddd", 25, "JS", "TS", "Angular");
greet(); // Default + Optional
//  e. Enum
var Direction;
(function (Direction) {
    Direction[Direction["Up"] = 0] = "Up";
    Direction[Direction["Down"] = 1] = "Down";
    Direction[Direction["Left"] = 2] = "Left";
    Direction[Direction["Right"] = 3] = "Right";
})(Direction || (Direction = {}));
var move = Direction.Up;
console.log("Direction:", Direction[move]);
