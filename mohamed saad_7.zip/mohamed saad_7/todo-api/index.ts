import fs from "fs";

const PORT = 3000;
// get-items.ts
import http, { IncomingMessage, ServerResponse } from "http";

interface Item {
  id: number;
  name: string;
}

let items: Item[] = [
  { id: 1, name: "MoSHa 1" },
  { id: 2, name: "MoSHa 2" },
  { id: 3, name: "MoSHa 3" },
];

const server = http.createServer((req, res) => {
  const { method, url } = req;

  if (req.method === 'GET' && req.url === '/api/todos') {
    fs.readFile('./todos.json', 'utf-8', (err, data) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Failed to read file' }));
      } else {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(items));
      }
    });
  } else {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ message: 'Route not found' }));
  }
});

server.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});