import http, { IncomingMessage, ServerResponse } from "http";

interface Item {
  id: number;
  name: string;
}

let items: Item[] = [
  { id: 1, name: "Item 1" },
  { id: 2, name: "Item 2" },
  { id: 3, name: "Item 3" },
];

const server = http.createServer(
  (req: IncomingMessage, res: ServerResponse) => {
    const { method, url } = req;

    if (url === "/api/items" && method === "GET") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(items));
    } else if (url === "/api/items" && method === "POST") {
      let body = "";
      req.on("data", (chunk) => {
        body += chunk.toString();
      });
      req.on("end", () => {
        const newItem: Item = JSON.parse(body);
        newItem.id = items.length + 1;
        items.push(newItem);
        res.writeHead(201, { "Content-Type": "application/json" });
        res.end(JSON.stringify(newItem));
      });
    } else if (url?.startsWith("/api/items/") && method === "PUT") {
      const id = parseInt(url.split("/")[3]);
      const item = items.find((i) => i.id === id);

      if (item) {
        let body = "";
        req.on("data", (chunk) => {
          body += chunk.toString();
        });
        req.on("end", () => {
          const updatedItem: Partial<Item> = JSON.parse(body);
          item.name = updatedItem.name || item.name;
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify(item));
        });
      } else {
        res.writeHead(404, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ message: "Item not found" }));
      }
    } else if (url?.startsWith("/api/items/") && method === "DELETE") {
      const id = parseInt(url.split("/")[3]);
      const index = items.findIndex((i) => i.id === id);

      if (index !== -1) {
        items.splice(index, 1);
        
        successJsonResponse(res, { message: "Item deleted" });
      } else {
        res.writeHead(404, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ message: "Item not found" }));
      }
    } else {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "Route not found" }));
    }
  }
);

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});


function successJsonResponse(
  res: ServerResponse,
  body: Record<string, any>
) {
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify(body));
}
