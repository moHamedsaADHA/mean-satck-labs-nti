// request-params.ts
import http, { IncomingMessage, ServerResponse } from "http";
import { parse } from "url";

// Create a server that extracts path parameters and query strings
const server = http.createServer(
  (req: IncomingMessage, res: ServerResponse) => {
    const { method, url } = req;

    // Parsing the URL to get pathname and query parameters
    const parsedUrl = parse(url || "", true);
    const pathname = parsedUrl.pathname;
    const query = parsedUrl.query;

    // Example: GET /api/items?id=1
    if (pathname === "/api/items" && method === "GET") {
      const itemId = query.id; // Extracting query parameter
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: `Item ID is ${itemId}` }));
    } else {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "Route not found" }));
    }
  }
);

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
