// middleware-logging.ts
import http, { IncomingMessage, ServerResponse } from "http";

// Custom logging middleware
const logRequest = (req: IncomingMessage): void => {
  const { method, url } = req;
  console.log(`${new Date().toISOString()} - ${method} ${url}`);
};

const server = http.createServer(
  (req: IncomingMessage, res: ServerResponse) => {
    logRequest(req); // Logging each request

    const { method, url } = req;

    if (url === "/api/items" && method === "GET") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "Request logged" }));
    } else {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "Route not found" }));
    }
  }
);

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
