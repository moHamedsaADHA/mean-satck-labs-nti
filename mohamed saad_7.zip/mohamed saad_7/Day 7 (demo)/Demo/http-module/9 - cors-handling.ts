// cors-handling.ts
import http, { IncomingMessage, ServerResponse } from "http";

// Function to set CORS headers
const setCorsHeaders = (res: ServerResponse): void => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, OPTIONS"
  );
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
};

const server = http.createServer(
  (req: IncomingMessage, res: ServerResponse) => {
    setCorsHeaders(res); // Apply CORS headers

    const { method, url } = req;

    if (url === "/api/items" && method === "GET") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "CORS headers set" }));
    } else if (method === "OPTIONS") {
      // Pre-flight requests handling for CORS
      res.writeHead(204);
      res.end();
    } else {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "Route not found" }));
    }
  }
);

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
