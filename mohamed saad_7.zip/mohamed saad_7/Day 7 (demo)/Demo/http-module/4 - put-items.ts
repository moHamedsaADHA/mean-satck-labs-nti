import http, { IncomingMessage, ServerResponse } from "http";
import { JsonHelper } from "./helpers/JsonHelper";

interface Item {
  id: number;
  name: string;
}

let items: Item[] = JsonHelper.read("./data/items.json");

const server = http.createServer(
  (req: IncomingMessage, res: ServerResponse) => {
    const { method, url } = req;

    if (url === "/api/items" && method === "GET") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(items));
    } else if (url === "/api/items" && method === "POST") {
      let body = "";
      req.on("data", (chunk) => {
        body += chunk.toString();
      });
      req.on("end", () => {
        const newItem: Item = JSON.parse(body);
        newItem.id = items.length + 1;
        items.push(newItem);
        JsonHelper.write("./data/items.json", items);
        res.writeHead(201, { "Content-Type": "application/json" });
        res.end(JSON.stringify(newItem));
      });
    } else if (url?.startsWith("/api/items/") && method === "PUT") {
      const id = parseInt(url.split("/")[3]);
      const item = items.find((i) => i.id === id);

      if (item) {
        let body = "";
        req.on("data", (chunk) => {
          body += chunk.toString();
        });
        req.on("end", () => {
          const updatedItem: Item = JSON.parse(body);
          item.name = updatedItem.name;
          JsonHelper.write("./data/items.json", items);
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify(item));
        });
      } else {
        res.writeHead(404, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ message: "Item not found" }));
      }
    } else {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "Route not found" }));
    }
  }
);

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
