import http, { IncomingMessage, ServerResponse } from "http";

// Create a basic server
const server = http.createServer(
  (req: IncomingMessage, res: ServerResponse) => {
    // res.writeHead(200, { "Content-Type": "text/html" });

    setInterval(() => {
      res.write("<h1>Hello World</h1>");
    }, 1000);

    setTimeout(() => {
      res.end("<h1>Request End</h1>");
    }, 6000);
  }
);

// Listen on port 3000
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server is running on port http://localhost:${PORT}`);
});

// node js
// async code
// event loop
// npm =>
//      node package manager => local
//      npm package manager => global
// in node js with typescript, we need to install types for each package we will install it by npm i @types/[package-name]
// some built in modules in node js (fs, path, http, os, url, EventEmitter)
// we can also create web server using node js http module and handle our requests
// each req and res has its own headers and body
// there are status codes that we can use with response like 2xx, 4xx, 5xx
// there are methods that we can use with request like get, post, put, delete
// response and request life cycle
// we can use different data source like in memory, json file, database.
// network models architecture => pear to pear, client server
// crud operation => create, read, update, delete using apis created by http module