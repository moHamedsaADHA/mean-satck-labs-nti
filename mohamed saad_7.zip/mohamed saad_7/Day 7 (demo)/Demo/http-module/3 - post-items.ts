import { JsonHelper } from "./helpers/JsonHelper";
import http, { IncomingMessage, ServerResponse } from "http";

interface Item {
  id: number;
  name: string;
}

let items: Item[] = JsonHelper.read("./data/items.json");

const server = http.createServer(
  (req: IncomingMessage, res: ServerResponse) => {
    const { method, url } = req;
    if (req.headers["content-type"] !== "application/json") {
      res.writeHead(400, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "Bad request" }));
    } else if (url === "/api/items" && method === "GET") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(items));
    } else if (url === "/api/items" && method === "POST") {
      let body = "";

      req.on("data", (chunk: Buffer) => {
        body += chunk.toString();
      });

      req.on("end", () => {
        const newItem: Item = JSON.parse(body);

        newItem.id = items.length + 1;
        items.push(newItem);

        JsonHelper.write("./data/items.json", items);

        res.writeHead(201, { "Content-Type": "application/json" });
        res.end(JSON.stringify(newItem));
      });
    } else {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "Route not found" }));
    }
  }
);

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
