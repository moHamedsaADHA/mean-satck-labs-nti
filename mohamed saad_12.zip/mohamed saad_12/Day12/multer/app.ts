import express, { NextFunction, Request, Response } from "express";
import fs from "fs";
import multer from "multer";

const app = express();

const storage = multer.diskStorage({
  destination: "uploads",
  filename(req, file, callback) {
    //students.router.ts

    const parts = file.originalname.split("."); // [students, router, ts]
    const ext = file.originalname.split(".")[parts.length - 1];
    const fileName = `${file.originalname}-${Date.now()}.${ext}`;

    if (file.originalname === "Test.txt") {
      callback(new Error("File already exists"), "");
    } else {
      callback(null, fileName);
    }
  },
});
// multipart/form-data

app.get(
  "/api/multer/any",
  multer({
    /* dest: "./uploads" */
    storage: storage,
    limits: {
      fileSize: 1000000,
    },
  }).single("image"), /// single File
  // multer().array("images", 1), //Files[]
  //   multer().fields([
  //     { name: "images", maxCount: 2 },
  //     { name: "files", maxCount: 2 },
  //   ]),
  // multiple files => { fieldName: Files[] } => [images: [], files: []]
  //   multer().any(), // Files[]
  (req, res) => {
    res.json({
      file: req.file?.originalname,
      files: req.files,
      body: req.body,
    });
  }
);

app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  res.status(500).json({ message: err.message });
});
app.listen(3000, () => {
  console.log("server is running on port 3000, http://localhost:3000");
});
