import { Student } from "../src/models/student.model";
import fs from "fs";

export const students: Student[] = JSON.parse(
  fs.readFileSync("./data/students.json", "utf-8")
);
