import { departments } from "./departments.data";
import { students } from "./students.data";

export const db = {
  students,
  departments,
  studentId: 2000,
  departmentId: 2000,
};
