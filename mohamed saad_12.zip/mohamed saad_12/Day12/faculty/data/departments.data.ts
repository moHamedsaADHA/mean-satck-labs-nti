import { Department } from "../src/models/department.model";
import fs from "fs";

export const departments: Department[] = JSON.parse(
  fs.readFileSync("./data/departments.json", "utf-8")
);
