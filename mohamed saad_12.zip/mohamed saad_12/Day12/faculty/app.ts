import express, { Request, Response } from "express";

import { studentRouter } from "./src/routers/students.router";
// import { parseIdMiddleware } from "./src/middlewares/parse-id.middleware";
import { departmentRouter } from "./src/routers/departments.router";
import { testRouter } from "./src/routers/test.router";
import { populateErrorsMiddleware } from "./src/middlewares/populate-errors.middleware";

const app = express();

const port = 3000;

app.use(express.json());

app.use(express.static("public"));

// app.use(parseIdMiddleware);

app.use(studentRouter);

app.use(departmentRouter);

app.use(testRouter);

app.get("/", (req: Request, res: Response) => {
  res.send("Hello, world!");
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
