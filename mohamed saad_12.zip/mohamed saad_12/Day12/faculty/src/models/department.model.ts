interface Department {
  id: number;
  name: string;
}

export { Department };
