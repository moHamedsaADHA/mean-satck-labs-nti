import { Request, Response } from "express";
import { Department } from "../../models/department.model";

type CreateDepartmentRequest = Request<
  {},
  {},
  {
    name: string;
  }
>;

type CreateDepartmentResponse = Response<Department>;

export { CreateDepartmentRequest, CreateDepartmentResponse };
