import { Request, Response } from "express";
import { Student } from "../../models/student.model";
import { ValidationError } from "express-validator";

type CreateStudentRequest = Request<
  {},
  {},
  {
    name: string;
    gender: "male" | "female";
  }
>;

type CreateStudentResponse = Response<Student | ValidationError[]>;

export { CreateStudentRequest, CreateStudentResponse };
