// validations/userValidation.ts
import { body } from "express-validator";

export const validateStudent = [
  body("name")
    .isString()
    .withMessage("Name must be a string")
    .notEmpty()
    .withMessage("Name is required"),

  body("gender")
    .isIn(["male", "female"])
    .withMessage("Gender must be either 'male' or 'female'"),
];
