import { RequestHandler } from "express";

// middleware to convert id to number
const parseIdMiddleware: RequestHandler<{ id: number }> = (req, res, next) => {
  console.log("id param", req.params.id);

  console.log(req.url);

  if (req.params.id) {
    req.params.id = +req.params.id;
  }
  next();
};

export { parseIdMiddleware };
