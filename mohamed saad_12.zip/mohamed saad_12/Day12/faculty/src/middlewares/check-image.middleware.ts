import { RequestHandler, Request } from "express";

const checkImageMiddleware: RequestHandler<{ id: number }> = (
  req,
  res,
  next
) => {
  const imageExts = ["jpg", "jpeg", "png", "gif"];

  if (!req.headers["content-type"]) {
    res.json({ message: "invalid image format" });
    return;
  } else {
    const imageExt = req.headers["content-type"].split("/")[1];

    if (imageExts.includes(imageExt)) {
      next();
      return;
    } else {
      res.status(400).json({
        message: "invalid image format, must be jpg, jpeg, png or gif",
      });
    }
  }
};

export { checkImageMiddleware };
