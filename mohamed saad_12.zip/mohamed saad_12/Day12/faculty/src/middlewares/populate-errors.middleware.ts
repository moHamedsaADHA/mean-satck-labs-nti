import { RequestHandler } from "express";
import { validationResult } from "express-validator";

const populateErrorsMiddleware: RequestHandler = (req, res, next) => {
  const result = validationResult(req);

  if (result.isEmpty()) return next();

  req.errors = result.array();

  res.status(400).json(req.errors.map((err) => err.msg));
};

export { populateErrorsMiddleware };
