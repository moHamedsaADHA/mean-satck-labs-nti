import fs from "fs";
import express, { Request, Response } from "express";
import { db } from "../../data/data";
import { Department } from "../models/department.model";
import {
  CreateDepartmentRequest,
  CreateDepartmentResponse,
} from "../requests/student/create-department.request";
import {} from 'multer';
const departmentRouter = express.Router();

// departments apis
departmentRouter.get("/api/departments", (req: Request, res: Response) => {
  res.json(db.departments);
});

departmentRouter.get(
  "/api/departments/:id",
  (req: Request<{ id: number }>, res: Response<Department>) => {
    const department = db.departments.find((s) => s.id === req.params.id);
    res.json(department);
  }
);

departmentRouter.post(
  "/api/departments",
  (req: CreateDepartmentRequest, res: CreateDepartmentResponse) => {
    const department = {
      id: db.departmentId++,
      name: req.body.name,
    };

    db.departments.push(department);

    fs.writeFileSync("./data/departments.json", JSON.stringify(db.departments));

    res.json(department);
  }
);

departmentRouter.put(
  "/api/departments/:id",
  (
    req: Request<
      { id: number },
      {},
      {
        name: string;
      }
    >,
    res: Response<{ message: string }>
  ) => {
    const index = db.departments.findIndex((d) => d.id === req.params.id);

    db.departments[index] = {
      ...db.departments[index],
      ...req.body,
    };

    fs.writeFileSync("./data/departments.json", JSON.stringify(db.departments));

    res.json({ message: "department has been updated successfully" });
  }
);

departmentRouter.delete(
  "/api/departments/:id",
  (req: Request<{ id: number }>, res: Response<{ message: string }>) => {
    const index = db.departments.findIndex((d) => d.id === req.params.id);

    db.departments.splice(index, 1);

    fs.writeFileSync("./data/departments.json", JSON.stringify(db.departments));

    res.json({ message: "student has been deleted successfully" });
  }
);

export { departmentRouter };
