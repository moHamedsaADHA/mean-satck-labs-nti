import express, { request, Router } from "express";
import {
  body,
  query,
  param,
  check,
  ValidationError,
  validationResult,
} from "express-validator";
import { populateErrorsMiddleware } from "../middlewares/populate-errors.middleware";

declare global {
  namespace Express {
    interface Request {
      errors: ValidationError[];
    }
  }
}

const testRouter = Router();

testRouter.post(
  "/api/test",
  check("name")
    .if((name) => {
      console.log(name);

      if (name[0] === "a") {
        return true;
      }
      return false;
    })
    .notEmpty()
    .withMessage("name is required")
    .isLength({ min: 8, max: 10 })
    .trim()
    .withMessage("name must be between 8 and 10 characters"),
  populateErrorsMiddleware,
  (req, res) => {
    res.json(req.body);
  }
);

export { testRouter };
