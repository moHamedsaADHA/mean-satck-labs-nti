import fs from "fs";
import express, { Request, Response } from "express";
import { db } from "../../data/data";
import { Student } from "../models/student.model";
import {
  CreateStudentRequest,
  CreateStudentResponse,
} from "../requests/student/create-student.request";
import { checkImageMiddleware } from "../middlewares/check-image.middleware";
import { parseIdMiddleware } from "../middlewares/parse-id.middleware";
import { validateStudent } from "../validators/studentValidation";
import { validationResult } from "express-validator";

const studentRouter = express.Router();

// students apis
studentRouter.get("/api/students", (req: Request, res: Response) => {
  res.json(db.students);
});

studentRouter.get(
  "/api/students/:id",
  parseIdMiddleware,
  (
    req: Request<{ id: number }>,
    res: Response<Student | { message: string }>
  ) => {
    const student = db.students.find((s) => s.id === req.params.id);

    if (!student) {
      res.status(404).json({ message: "student not found" });
      return;
    }

    res.json(student);
  }
);

studentRouter.post(
  "/api/students",
  validateStudent,
  (req: CreateStudentRequest, res: CreateStudentResponse) => {
    const result = validationResult(req);

    if (!result.isEmpty()) {
      res.status(400).json(result.array().map((err) => err.msg));
      return;
    }
    const student: Student = {
      id: db.studentId++,
      name: req.body.name,
      gender: req.body.gender,
      email: undefined,
      image: undefined,
    };

    db.students.push(student);

    fs.writeFileSync("./data/students.json", JSON.stringify(db.students));

    res.json(student);
  }
);

studentRouter.put(
  "/api/students/:id",
  parseIdMiddleware,
  (
    req: Request<
      { id: number },
      {},
      {
        name: string;
        gender: "male" | "female";
        email?: string;
      }
    >,
    res: Response<{ message: string }>
  ) => {
    const index = db.students.findIndex((s) => s.id === req.params.id);

    db.students[index] = {
      ...db.students[index],
      ...req.body,
    };

    fs.writeFileSync("./data/students.json", JSON.stringify(db.students));

    res.json({ message: "student has been updated successfully" });
  }
);

studentRouter.delete(
  "/api/students/:id",
  (req: Request<{ id: number }>, res: Response<{ message: string }>) => {
    const index = db.students.findIndex((s) => s.id === req.params.id);

    db.students.splice(index, 1);

    fs.writeFileSync("./data/students.json", JSON.stringify(db.students));

    res.json({ message: "student has been deleted successfully" });
  }
);

studentRouter.patch(
  "/api/students/:id/image",
  express.raw({ limit: "4mb", type: "image/*" }),
  checkImageMiddleware,
  parseIdMiddleware,
  (req: Request<{ id: number }>, res) => {
    const student = db.students.find((s) => s.id === req.params.id);

    if (!student) {
      res.status(404).json({ message: "student not found" });
      return;
    }

    //image/jpeg => ['image', 'jpeg']
    let imageExt = "jpg";
    if (req.headers["content-type"]) {
      imageExt = req.headers["content-type"].split("/")[1];
    }

    const imageName = `${student.name + "-" + Date.now()}.${imageExt}`;

    // remove old student image
    if (student.image && fs.existsSync(`./public/images/${student.image}`)) {
      fs.unlinkSync(`./public/images/${student.image}`);
    }

    // save new student image
    fs.writeFileSync(`./public/images/${imageName}`, req.body);

    // update student
    student.image = imageName;

    // update students data
    fs.writeFileSync("./data/students.json", JSON.stringify(db.students));

    res.json(student);
  }
);

studentRouter.get(
  "/api/students/:id/department",
  parseIdMiddleware,
  (
    req: Request<{ id: number }>,
    res: Response<
      { studentName: string; departmentName: string } | { message: string }
    >
  ) => {
    const student = db.students.find((s) => s.id === req.params.id);

    if (!student) {
      res.status(404).json({ message: "student not found" });
      return;
    }

    const department = db.departments.find(
      (d) => d.id === student.departmentId
    );

    if (!department) {
      res.status(404).json({ message: "student has no department" });
      return;
    }

    const response = {
      studentName: student.name,
      departmentName: department.name,
    };

    res.json(response);
  }
);

export { studentRouter };
