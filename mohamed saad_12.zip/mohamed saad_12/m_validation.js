import express from "express";
import { body, query, validationResult } from "express-validator";

const app = express();
const PORT = 3000;

// ✅ middlewares
app.use(express.json());

// ✅ mock database وهذا مثال على قاعدة بيانات وهمية
let mockUsers = [
  { name: "mosha", email: "mosha@example.com", role: "admin" },
];

// ✅ GET route with query validation
app.get("/api/users",query("filter").isString().notEmpty().withMessage("Filter must be a non-empty string"),
  (request, response) => {
    const errors = validationResult(request);
    if (!errors.isEmpty()) {
      return response.status(400).json({ errors: errors.array() });
    }

    const {
      query: { filter, value },
    } = request;

    if (filter && value) {
      return response.send(
        mockUsers.filter((user) =>
          user[filter]?.toLowerCase().includes(value.toLowerCase())
        )
      );
    }

    return response.send(mockUsers);
  }
);

// ✅ POST route with body validation
app.post(
  "/api/users",
  [
    body("name").isString().notEmpty().withMessage("Name is required"),
    body("email").isEmail().withMessage("Valid email is required"),
    body("role").isIn(["admin", "user"]).withMessage("Role must be admin or user"),
  ],
  (request, response) => {
    const errors = validationResult(request);
    if (!errors.isEmpty()) {
      return response.status(400).json({ errors: errors.array() });
    }

    const newUser = request.body;
    mockUsers.push(newUser);
    response.status(201).json({ msg: "User added successfully", user: newUser });
  }
);

// ✅ default route
app.get("/", (req, res) => {
  res.status(200).send({ msg: "Hello from Express API 🚀" });
});

// ✅ start server
app.listen(PORT, () => {
  console.log(`Running on Port ${PORT}`);
});
