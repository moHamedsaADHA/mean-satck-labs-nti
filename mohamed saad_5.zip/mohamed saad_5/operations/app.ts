import { Calculator } from '../classes/calculater';
import * as readline from 'readline';
import { calculate } from './calculate';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question('Enter first number: ', (first) => {
    rl.question('Enter operator (+, -, *, /): ', (operator) => {
        rl.question('Enter second number: ', (second) => {
            const a = parseFloat(first);
            const b = parseFloat(second);
            const result = calculate(a, b, operator);
            console.log(`Result: ${result}`);
            rl.close();
        });
    });
});
