// this is file name_age_lab5.ts in operating system mooshaaaa
import * as readline from 'readline';
import { name_age_lab5 } from './classes/lab5';

name_age_lab5.run();
