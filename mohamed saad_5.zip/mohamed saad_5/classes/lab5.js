"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.name_age_lab5 = void 0;
class name_age_lab5 {
    static run() {
        const input = process.stdin;
        const output = process.stdout;
        const rl = require('readline').createInterface({
            input,
            output
        });
        rl.question('What is your name? ', (name) => {
            rl.question('What is your age? ', (age) => {
                console.log(`Hello, ${name}! You are ${age} years old.`);
                rl.close();
            });
        });
    }
}
exports.name_age_lab5 = name_age_lab5;
