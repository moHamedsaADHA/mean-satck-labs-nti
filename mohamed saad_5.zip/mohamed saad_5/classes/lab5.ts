import * as readline from 'readline';
//import {} from 'readline';

export class name_age_lab5 {
    static run() {
        const input = process.stdin;
        const output = process.stdout;

        const rl = readline.createInterface({
            input,
            output
        });

        rl.question('What is your name? ', (name: string) => {
            rl.question('What is your age? ', (age: string) => {
                console.log(`Hello, ${name}! You are ${age} years old.`);
                rl.close();
            });
        });
    }
}
