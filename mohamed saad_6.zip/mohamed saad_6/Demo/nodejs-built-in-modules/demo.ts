import fs from "fs";
import path from "path";

// fs.readFile("./example.txt", { encoding: "utf-8" }, (err, data) => {
//   console.log("data", data);
//   console.log("err", err?.message);
// });

// try {
//   //   let data = fs.readFileSync("./example2.txt", { encoding: "utf-8" });

//   throw new Error("error occured");
// } catch (error) {
//   console.log(error.message);
// }

// console.log("ali");

// console.log(data);

// try {
//   fs.writeFileSync("example.txt", "Hello, this is new content!");
//   console.log("File written successfully.");
// } catch (err) {
//   console.error("Error writing to file:", err);
// }

// Read input from the console (stdin)
import { createInterface } from "readline";

// Create an interface for reading input and writing output
// const rl = createInterface({
//   input: process.stdin,
//   output: process.stdout,
// });

// rl.question("write your name", (name: string) => {
//   fs.appendFile("example.txt", `\n${name}`, (err) => {
//     if (err) {
//       console.error("Error appending to file:", err);
//       return;
//     }
//     console.log("Data appended successfully.");
//     rl.close();
//   });
// });
// // Asynchronous append

// // Delete a file
// fs.unlink("example.txt", (err) => {
//   if (err) {
//     console.error("Error deleting file:", err);
//     return;
//   }
//   console.log("File deleted successfully.");
// });

// // Rename a file
// fs.rename("example.txt", "example2.txt", (err) => {
//   if (err) {
//     console.error("Error renaming file:", err);
//     return;
//   }
//   console.log("File renamed successfully.");
// });

// let p = path.join(__dirname, "folder");

// if (!fs.existsSync(p)) {
//   fs.mkdirSync(p);
// }

// fs.writeFileSync(path.join(p, "file.txt"), "Hello, this is new content!");

// const folder = path.dirname(p);
// if (!fs.existsSync(folder)) {
//   fs.mkdirSync(folder, { recursive: false });
// }

// fs.writeFileSync(p, "Hello, this is new content!", { encoding: "utf-8" });

const parsedPath = path.parse(__filename);
console.log("Parsed path:", parsedPath);
