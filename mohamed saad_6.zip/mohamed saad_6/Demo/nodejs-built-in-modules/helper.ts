export function add(a: number, b: number) {
  return a + b;
}

function sub(a: number, b: number) {
  return a - b;
}

export class Helper {
  static add(a: number, b: number) {
    return a + b;
  }

  static sub(a: number, b: number) {
    return a - b;
  }
}

export const helper = {
  add,
  sub,
  Helper,
};
