import path from "path";

// Get the base file name
console.log("Base file name:", path.basename(__filename));

// Get the directory name
console.log("Directory name:", path.dirname(__filename));

// Get the file extension
console.log("File extension:", path.extname(__filename));

// Join paths
console.log("Joined path:", path.join(__dirname, "folder", "file.txt"));
// Parse a path

const parsedPath = path.parse(__filename);
console.log("Parsed path:", parsedPath);
