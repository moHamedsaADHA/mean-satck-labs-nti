import fs from "fs";

// Synchronous read
try {
  const data = fs.readFileSync("example.txt", "utf8");
  console.log("File content:", data);
} catch (err) {
  console.error("Error reading file:", err);
}

// Synchronous write
try {
  fs.writeFileSync("example.txt", "Hello, this is new content!");
  console.log("File written successfully.");
} catch (err) {
  console.error("Error writing to file:", err);
}

// Asynchronous append
fs.appendFile("example.txt", " Appended text.", (err) => {
  if (err) {
    console.error("Error appending to file:", err);
    return;
  }
  console.log("Data appended successfully.");
});

// Delete a file
fs.unlink("example.txt", (err) => {
  if (err) {
    console.error("Error deleting file:", err);
    return;
  }
  console.log("File deleted successfully.");
});

// Watch a file for changes
fs.watchFile("example.txt", (curr, prev) => {
  console.log(`File changed! Previous modification time: ${prev.mtime}`);
  console.log(`Current modification time: ${curr.mtime}`);
});
