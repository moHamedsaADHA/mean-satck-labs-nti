import fs from "fs";

export class JsonHelper {
  static read<T>(path: string): T {
    return JSON.parse(fs.readFileSync(path, { encoding: "utf-8" }));
  }

  static write<T>(path: string, data: T) {
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
  }
}
