// Read input from the console (stdin)
import * as readline from "readline";

// Create an interface for reading input and writing output
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("What is your name? \n", (name: string) => {
  console.log(`Hello, ${name}!`);
  rl.question("What is your age? \n", (age) => {
    console.log(`You are ${age}!`);
    rl.close();
  });
});
