const add = () => {
  return 5;
};

console.log("hi am here");

let x = 5;

x = 10;

add();
setTimeout(() => {
  console.log(x);
}, 5000);

setTimeout(() => {
  while (x++) {
    if (x == 2000000000) break;
  }
});

setInterval(() => {
  console.log(x);
}, 1000);
console.log("hello world 1 ");

x = 0;
while (x++) {
  if (x == 2000000000) break;
}
console.log("hello world 2");

let y = 60;

y = y + x;

// setTimeout(() => {
//   console.log(y);
// }, 3000);

console.log("Hello World");

//synchronous code
// asynchronous code

function caluc1() {
  while (x++) {
    if (x > 2000000000) break;
  }
}

function caluc2() {
  while (y++) {
    if (y > 2000000000) break;
  }
}

setTimeout(() => {
  caluc1();
});
setTimeout(() => {
  caluc2();
});
