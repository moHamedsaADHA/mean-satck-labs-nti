import { helper, Helper } from "./helper";
import { JsonHelper} from './JsonHelper'

import fs from "fs";

// console.log(helper.add(5, 10));

// Helper.add(5, 10);
// Helper.sub(5, 10);

// let data = fs.readFileSync("./Nodejs.txt", { encoding: "utf-8" });

// console.log(data);

// fs.writeFileSync("./Nodejs2.txt", "Hello, this is new content!");

// let data = fs.readFileSync("./users.json", { encoding: "utf-8" });

// let data = JsonHelper.read<{ id: number; name: string }[]>("./users.json");

// let jsonData = data;

// console.log(jsonData);

// jsonData.push({ id: 5, name: "New User 5" });

// // fs.writeFileSync("./users.json", JSON.stringify(jsonData, null, 2));
// JsonHelper.write("./users.json", jsonData);


// console.log(__dirname);

