import os from "os";

// Get the OS platform
console.log("OS Platform:", os.platform());

// Get the CPU architecture
console.log("CPU Architecture:", os.arch());

// Get information about each CPU/core installed
console.log("CPU Info:", os.cpus());

// Get free memory
console.log("Free Memory:", os.freemem());

// Get total memory
console.log("Total Memory:", os.totalmem());

// Get home directory
console.log("Home Directory:", os.homedir());

// Get system uptime in seconds
console.log("System Uptime:", os.uptime(), "seconds");
