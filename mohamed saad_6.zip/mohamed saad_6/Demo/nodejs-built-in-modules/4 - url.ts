import { URL } from "url";

// Create a new URL object
const myUrl = new URL(
  "https://example.com:8000/path/name?search=abc&sort=desc"
);

// Get the serialized URL
console.log("Serialized URL:", myUrl.href);

// Get the host (hostname and port)
console.log("Host:", myUrl.host);

// Get the hostname
console.log("Hostname:", myUrl.hostname);

// Get the pathname
console.log("Pathname:", myUrl.pathname);

// Get the search parameters
console.log("Search Params:", myUrl.search);

// Add a new search parameter
myUrl.searchParams.append("newParam", "value");
