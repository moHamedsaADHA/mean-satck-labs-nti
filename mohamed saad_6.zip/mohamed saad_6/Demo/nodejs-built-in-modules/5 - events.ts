import { EventEmitter } from "events";

// Create an instance of EventEmitter
const emitter = new EventEmitter();

let cnt = 1;
// Define an event handler
emitter.on("greet", (name) => {
  console.log(`Hello, ${cnt++}!`);
});

emitter.on("click", (name) => {
  console.log(`click, ${name}!`);
});

setInterval(() => {
  // Emit the 'greet' event
  emitter.emit("greet", "Node.js Developer");
}, 2000);

setInterval(() => {
  // Emit the 'greet' event
  emitter.emit("click", "click Developer");
}, 2000);
