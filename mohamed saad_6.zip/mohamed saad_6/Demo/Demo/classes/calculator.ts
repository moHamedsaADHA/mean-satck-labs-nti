interface ICalulator {
  sum(a: number, b: number): number;
  subs(a: number, b: number): number;
  mult(a: number, b: number): number;
  div(a: number, b: number): number;
}

export { ICalulator };

export class Casio implements ICalulator {
  sum(a: number, b: number): number {
    return a + b;
  }
  subs(a: number, b: number): number {
    return a - b;
  }
  mult(a: number, b: number): number {
    return a * b;
  }
  div(a: number, b: number): number {
    return a / b;
  }
}

export class Calculator implements ICalulator {
  sum(a: number, b: number): number {
    return a + b;
  }
  subs(a: number, b: number): number {
    return a - b;
  }
  mult(a: number, b: number): number {
    return a * b;
  }
  div(a: number, b: number): number {
    return a / b;
  }
}
