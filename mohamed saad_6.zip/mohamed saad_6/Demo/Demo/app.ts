import { createInterface } from "readline";
import { sum } from "./operations/sum";
import { subs } from "./operations/subs";
import { mult } from "./operations/mult";
import { div } from "./operations/div";
import { Calculator, Casio, ICalulator } from "./classes/calculator";

const rl = createInterface({
  input: process.stdin,
  output: process.stdout,
});

// npm init -y
// tsc --init
// npm i tsx
// npm i @types/node

// npx tsx [filename].ts => use this to compile

const calculator: ICalulator = new Calculator();

rl.question("Choose operation (+, -, *, /): ", (operation) => {
  rl.question("Enter first number: ", (a) => {
    rl.question("Enter second number: ", (b) => {
      let result: number = 0;
      if (operation === "+") {
        result = calculator.sum(+a, +b);
      } else if (operation === "-") {
        result = calculator.subs(+a, +b);
      } else if (operation === "*") {
        result = calculator.mult(+a, +b);
      } else if (operation === "/") {
        result = calculator.div(+a, +b);
      }
      console.log(`Result: ${result}`);
      rl.close();
    });
  });
});
