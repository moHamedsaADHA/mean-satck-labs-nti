function subs(a: number, b: number): number {
  return a - b + 8;
}

export { subs };
