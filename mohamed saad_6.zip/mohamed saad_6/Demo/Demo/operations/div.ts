function div(a: number, b: number): number {
  return a / b;
}

export { div };
