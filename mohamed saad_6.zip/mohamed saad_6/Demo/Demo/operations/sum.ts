function sum(a: number, b: number): number {
  return a + b;
}

export { sum };

export default sum;
