import { readFileSync, writeFileSync, existsSync, writeFile } from 'fs';
import path from 'path';
import { URL } from 'url';
import readline from 'readline';

try {
  // =========================
  // 1️⃣ FS Task + Bonus
  // =========================
  if (existsSync('input.txt')) {
    const data = readFileSync('input.txt', 'utf-8');
    const words = data.split(/\s+/).filter(word => word.length > 0);
    const wordCount = words.length;
    writeFileSync('summary.txt', `Number of words: ${wordCount}`);
    console.log(`summary.txt created with ${wordCount} words.`);
  } else {
    console.log('input.txt does not exist. Creating and prompting user...');

    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });

    rl.question('Please enter content for input.txt: ', (answer: string) => {
      writeFile('input.txt', answer, (err) => {
        if (err) {
          console.error('Error writing file:', err);
        } else {
          console.log('input.txt created. Please run the script again.');
        }
        rl.close();
      });
    });
    process.exit(0);
    
    // Stop here since readline is async
}

  // =========================
  // 2️⃣ Path Task
  // =========================
  const filePath = path.join(__dirname, 'data.json');

  console.log('\n Path Info:');
  console.log('Directory name:', path.dirname(filePath));
  console.log('Base name:', path.basename(filePath));
  console.log('File extension:', path.extname(filePath));

  // =========================
  // 3️⃣ URL Task
  // =========================
  const siteUrl = 'https://example.com/products?page=2&limit=10&category=books';
  const parsedUrl = new URL(siteUrl);

  console.log('\n URL Info:');
  console.log('Hostname:', parsedUrl.hostname);
  console.log('Pathname:', parsedUrl.pathname);

  console.log('Query Parameters:');
  parsedUrl.searchParams.forEach((value, key) => {
    console.log(`${key}: ${value}`);
  });

  // =========================
  // 4️⃣ Search Namespace
  // =========================

  console.log('\n Search Test:');
  console.log(Search.find('TypeScript is powerful', 'powerful')); // true
  console.log(Search.find('TypeScript is powerful', 'weak'));     // false

} catch (err) {
  console.error('Something went wrong:', err);
}

namespace Search {
  export function find(text: string, term: string): boolean {
    return text.includes(term);
  }
}
